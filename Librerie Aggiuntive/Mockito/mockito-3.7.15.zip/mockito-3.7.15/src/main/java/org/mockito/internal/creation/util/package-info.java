/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Stuff that does not have a good package yet.
 */
package org.mockito.internal.creation.util;
